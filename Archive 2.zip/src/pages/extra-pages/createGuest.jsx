import React from 'react'

const createGuest = () => {
  return (
    <div>
      
    </div>
  )
}

export default createGuest
