// import React from 'react'
// import { useTheme } from '@mui/material/styles';
// import Typography from 'themes/typography';

// const NoPageFound = () => {

//     const theme = useTheme();

//   return (
//     <Typography variant="h6">Size: 14px</Typography>
//   )
// }

// export default NoPageFound


import React from 'react'

const NoPageFound = () => {
  return (
    <img />
  )
}

export default NoPageFound
