import React from 'react'

const SuccessfulPayments = () => {
  return (
    <div>SuccessfulPayments</div>
  )
}

export default SuccessfulPayments