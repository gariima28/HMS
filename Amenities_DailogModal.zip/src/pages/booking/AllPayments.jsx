import React from 'react'

const AllPayments = () => {
  return (
    <div>AllPayments</div>
  )
}

export default AllPayments