import React from 'react'

const FailedPayments = () => {
  return (
    <div>FailedPayments</div>
  )
}

export default FailedPayments