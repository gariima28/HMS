import React from 'react'

const ApprovedPayments = () => {
  return (
    <div>ApprovedPayments</div>
  )
}

export default ApprovedPayments