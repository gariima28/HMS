import React from 'react'

const RejectedPayments = () => {
  return (
    <div>RejectedPayments</div>
  )
}

export default RejectedPayments